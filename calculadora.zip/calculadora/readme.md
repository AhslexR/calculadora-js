esta es la tarea 2  Ashly DIaz Reyes

![mi captura](image.png)